public class Server extends ComputerImpl{
    public Server(String maker, String model, String cpu, String ram, String hardDrive) {
        super(maker, model, cpu, ram, hardDrive);
    }
}
