public abstract class PortableComputer extends ComputerImpl {
    public PortableComputer(String maker, String model, String cpu, String ram, String hardDrive) {
        super(maker, model, cpu, ram, hardDrive);
    }
}
