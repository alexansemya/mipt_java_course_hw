public interface Computer
{
    String turnOn();
    String turnOff();
    String connect();
}

