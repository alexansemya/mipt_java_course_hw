public abstract class DesktopComputer extends ComputerImpl {
    public DesktopComputer(String maker, String model, String cpu, String ram, String hardDrive) {
        super(maker, model, cpu, ram, hardDrive);
    }
}
