public class Nettop extends DesktopComputer{
    public Nettop(String maker, String model, String cpu, String ram, String hardDrive) {
        super(maker, model, cpu, ram, hardDrive);
    }
}
